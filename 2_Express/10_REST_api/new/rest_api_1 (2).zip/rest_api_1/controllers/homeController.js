import {join} from 'path'

var objPersons=[
    {pid:1,name:'Krishna Aryal',Address:'ktm'},
    {pid:2,name:'asim',Address:'lat'},
    {pid:3,name:'suraj',Address:'ktm'},
    {pid:4,name:'bishal',Address:'lat'},
    {pid:5,name:'mitra',Address:'nawalparasi'}
];
const indexController = (request, response)=>{
    // response.render(join(process.cwd(), 'views', 'index'));
    response.status(200).send({message:"index ho hai"});
}
const homeController = (request, response)=>{
    // response.render(join(process.cwd(), 'views', 'index'));
    //create an array of person object
    
    // response.status(200).send({persons:"All Persons."});
    response.status(200).send(objPersons);
}
const singleController = (request, response)=>{
    // response.render(join(process.cwd(), 'views', 'index'));
    // var {id} =request.params
    
    // receive id
    var {id} =request.params
    console.log(id);
            var result={};
            objPersons.forEach((item,index,array) => {
            console.log(item)
            if(item.pid==id){
                result.result=item    //second result chai object ko component
                result.status=true  //'record found'
            }
            else{
                result.status=false   //'record  not found'

            }
        });
   
    // search record on onjPersons based on id
    console.log(result);
    response.status(200).send({person:`Individual Person.-${id}`});
    // console.log(request.params)
}

const newController = (request, response)=>{
    // response.render(join(process.cwd(), 'views', 'index'));
    response.status(201).send({message:"Add new person."});
}

const putController = (request, response)=>{
    // response.render(join(process.cwd(), 'views', 'index'));
    response.status(200).send({message:"Update person."});
}
const patchController = (request, response)=>{
    // response.render(join(process.cwd(), 'views', 'index'));
    response.status(200).send({message:"Update person partially "});
}

const delController = (request, response)=>{
    // response.render(join(process.cwd(), 'views', 'index'));
    response.status(200).send("Delete person.");
}

export{indexController,homeController, singleController, newController, putController, patchController, delController}