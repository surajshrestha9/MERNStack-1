import {join} from 'path'

const homeController = (request, response)=>{
    response.render(join(process.cwd(), 'views', 'index'));
}

export{homeController}