var hello = function(){
	alert("Hello from myfunction");
}