// Example-14 - Looping in Express
var express = require("express");
var path = require("path");
var app = express();
app.set('view engine', 'ejs');
app.get('', (request, response)=>{
    response.render('index');
});
app.get('/about', (request, response)=>{
    const user = {
        id:1,
        name:'Raj Thapa',
        address:'Kathmandu',
        emails:['raj@gmail.com','raj@yahoo.com'],
    }
    response.render('about', {user});
});
app.listen(8000);