// Route

//Example-1 - Sending Parameters
var express = require("express");
var app = express();

app.get('/:id/:name/:address', (request, response)=>{
    console.log(request.params);
    response.send("Hello");
});
app.listen(8000);