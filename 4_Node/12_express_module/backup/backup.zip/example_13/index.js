// Example-13 - Template engine
// npm install ejs

var express = require("express");
var path = require("path");
var app = express();
app.set('view engine', 'ejs');
app.get('', (request, response)=>{
    response.render('index');
});
app.get('/about', (request, response)=>{
    const user = {
        id:1,
        name:'Raj Thapa',
        address:'Kathmandu'
    }
    response.render('about', {user});
});
app.get('/clients', (request, response)=>{
    const users =[ 
        {id:1, name:'Raj Thapa', address:'Kathmandu'},
        {id:2, name:'Raju Rai', address:'Lalitpur'},
        {id:3, name:'Kiran Sharma', address:'Bhaktapur'},
    ];    
    response.render('clients', {users});
});
app.listen(8000);