// npm install nodemon --location=global
// npm install express --location=global
// npm audit fix
// npm audit fix --force

// Example-1 - Simple Server
/*
var express = require("express");
var app = express();
app.get('',(request, response)=>{
    response.send("Hello world of Express");
});
app.listen(8000);
*/

// Example-2 - Multiple Request
/*
var express = require("express");
var app = express();
app.get('',(request, response)=>{
    response.send("Hello world of Express");
});
app.get('/about',(request, response)=>{
    response.send("About Us");
});
app.get('/services',(request, response)=>{
    response.send("Our Services");
});
app.get('/contact',(request, response)=>{
    response.send("Contact with Us");
});
app.listen(8000);
*/

// Example-2-1 - Reading Contents from text file
/*
var express = require("express");
var fs = require("fs");

var app = express();
app.get('',(request, response)=>{
    // response.send("Hello world of Express");    

    // Reading file - async
    fs.readFile("./data/index.txt", "utf-8", (err, data)=>{
        response.send(data);
    });
    
    // Reading file - sync    
    // const data = fs.readFileSync('./data/index.txt', {encoding:'utf8', flag:'r'});
    // response.send(data);
});

app.get('/about',(request, response)=>{
    // response.send("About Us");
    const data = fs.readFileSync('./data/about.txt', {encoding:'utf8', flag:'r'});
    response.send(data);
});

app.get('/services',(request, response)=>{
    // response.send("Our Services");
    const data = fs.readFileSync('./data/services.txt', {encoding:'utf8', flag:'r'});
    response.send(data);
});
app.get('/contact',(request, response)=>{
    // response.send("Contact with Us");
    const data = fs.readFileSync('./data/contact.txt', {encoding:'utf8', flag:'r'});
    response.send(data);
});
app.get('*',(request, response)=>{
    // response.send("Contact with Us");
    const data = fs.readFileSync('./data/pagenotfound.txt', {encoding:'utf8', flag:'r'});
    response.send(data);
});
app.listen(8000);
*/

// Example-3 - Request & Response
/*
var express = require("express");
var app = express();
// Receive from request
app.get('',(request, response)=>{
    // 127.0.0.1?id=1&name=Raj Rai&address=Ktm
    // console.log(request);
    console.log(request.query); //{ id: '1', name: 'Raj Rai', address: 'Ktm' }
    response.send("Hello world of Express");
});
app.listen(8000);
*/

// Example-4 - Render HTML Content
/*
var express = require("express");
var app = express();
// Receive from request
app.get('',(request, response)=>{       
    response.send(`
        <input type="text" placeholder="user name"/>
        <button>Click me</button>
    `);
});
app.listen(8000);
*/

// Example-5 - Render JSON-String
/*
var express = require("express");
var app = express();
// Receive from request
app.get('',(request, response)=>{       
    response.send(`{
        id:1,
        name:'Raj Rai',
        address:'Kathmandu'
    }`);
});
app.listen(8000);
*/

// Example-6 - Hyperlink
/*
var express = require("express");
var app = express();
// Receive from request
app.get('',(request, response)=>{       
    response.send(`[
    <a href='/'>Index</a> | 
    <a href='/about'>About Us</a> | 
    <a href='/services'>Our Services</a> | 
    <a href='/contact'>Contact Us</a>
    ]`);
});
app.get('/about',(request, response)=>{       
    response.send(`About Us`);
});
app.get('/services',(request, response)=>{       
    response.send(`Our Services`);
});
app.get('/contact',(request, response)=>{       
    response.send(`Contact Us`);
});
app.listen(8000);
*/

// Example-8 - 404 Not found
/*
var express = require("express");
var app = express();
app.get('',(request, response)=>{       
    response.send(`<h1>Welcome to mysite.com</h1>`);
});
app.get('/about',(request, response)=>{       
    response.send(`<h1>About Us</h1>`);
});
app.use('',(request, response)=>{       
    response.send(`<h1>404 Page not found!</h1>`);
});
app.listen(8000);
*/

// Example-9 - Render HTML File
/*
var express = require("express");
var path = require("path");

var app = express();
var filePath = path.join(__dirname, "example_9");

app.get('',(request, response)=>{       
    response.send(``);
});
app.use(express.static(filePath));
app.listen(8000);
*/

// Example-10 - Render HTML File-2
/*
var express = require("express");
var path = require("path");
var app = express();
var filePath = path.join(__dirname, "example_10");
app.get('',(request, response)=>{       
    response.sendFile(`${filePath}/index.html`);
});
app.get('/about', (request, response)=>{
    response.sendFile(`${filePath}/about.html`);
});
app.listen(8000);
*/

// Example-11 - Render HTML file, remove file extension and 404 page not found
/*
var express = require("express");
var path = require("path");
var app = express();
const filePath = path.join(__dirname, "example_11")
app.get('', (request, response)=>{
    response.sendFile(`${filePath}/index.html`);
});
app.get('/about', (request, response)=>{
    response.sendFile(`${filePath}/about.html`);
});
app.get('*', (request, response)=>{
    response.sendFile(`${filePath}/pagenotfound.html`);
});
app.listen(8000);
*/

// Example-12 - Templating
// Example-13 - Sending Data to Template
// Example-14 - Dynamic Pages
// Example-15 - Getting Data from Url/WebForm with GET/POST method