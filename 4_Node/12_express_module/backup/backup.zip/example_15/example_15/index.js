// npm install express
// npm install --save body-parser multer
// npm install --save body-parser
// npm install nodemon
// npm audit fix
// npm audit

const express = require('express');
var bodyParser = require('body-parser')
var path = require("path");
var app = express();
var urlencodedParser = bodyParser.urlencoded({ extended: false });

const filePath = path.join(__dirname, "public")

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('', (request, response)=>{
    response.sendFile(`${filePath}/index.html`);
});

app.get('/form1', (request, response)=>{
    response.sendFile(`${filePath}/form1.html`);
});

app.get('/form2', (request, response)=>{
    response.sendFile(`${filePath}/form2.html`);
});

app.get('/getForm1', (req, res) => {
    first_name =req.query['first_name']; 
    last_name =req.query['last_name'];        
    obj1 = {  
        first_name:first_name,  
        last_name:last_name  
    };     
    console.log(res);  
    res.end(JSON.stringify(obj1)); 
});

app.post('/getForm2', urlencodedParser, function (req, res) {  
    obj1 = {
        first_name:req.body.first_name,  
        last_name:req.body.last_name  
    };
    console.log(obj1);
    res.end(JSON.stringify(obj1));
})

app.get('*', (request, response)=>{
    response.sendFile(`${filePath}/pagenotfound.html`);
});
app.listen(8000);