var homeController=(request, response)=>{
    response.render('home');
};

export {homeController};