import { insertRecord, getAll } from "../databases/mongo_client.js";

var homeController =  (request, response) => {
    var objPersons= getAll();
    response.render('home',{objPersons});  //display all persons in  home.ejs
};
var formController = (request, response) => {
    response.render('addnew');
};
var saveController = (request, response) => {  
    //you may write database code here
    // receive values

    var {txtname, txtAddress}=request.query;
    console.log(txtname,txtAddress)
    // send to mongo_client ->saveRecord()
    // var res=insertRecord({name:txtname,address:txtAddress})
    var obj1={name:txtname,address:txtAddress}
    var res= insertRecord(obj1)
    // receive result and redirect to view
    console.log(res)
    if(res){
        response.send('save record successfully');
    }
    else{
        response.send('error to send record')
    }
};

export { homeController, formController, saveController };